
param(
    [int]$hours=6
)

$SpooledJobs = Get-ChildItem -Path "$env:systemroot\System32\Spool\Printers" -File -Recurse | 
    Where-Object { $_.CreationTime -lt (Get-Date).AddHours(-$hours) }
If ($SpooledJobs) {
    Write-Warning "Old job detected; restarting print spooler service"
    Restart-Service -Name Spooler
}
