
Get-Service | Where-Object { $_.Status -eq 'Running' } | Select-Object Name,Status,StartType,BinaryPathName |
    ConvertTo-HTML | Out-File ("{2}\Services-{0:MMddyyyy}.{1}" -f (get-date),"htm",$env:TEMP)

Get-Service | Where-Object { $_.Status -eq 'Running' } | ConvertTo-JSON |
    Out-File ("{2}\Services-{0:MMddyyyy}.{1}" -f (get-date),"json",$env:TEMP)


    (get-date).tostring(“yyMMddHHmmssffff”)
