
Get-Service | Where-Object { $_.Status -eq "Running" }

Get-Service | Select-Object -Property Name,Status,StartType,BinaryPathName
