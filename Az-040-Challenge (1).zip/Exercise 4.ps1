$LogFiles = Get-CHildItem -Path ("{1}\Services-{0:MMddyyyy}*" -f (get-date),$env:TEMP) -File
If ($LogFiles.Count -ge 2) {
    Write-Host "All is good"
} else  {
    Write-Error "FILE is Misssing"
}

$SpooledJobs = Get-ChildItem -Path "$env:systemroot\System32\Spool\Printers" -File -Recurse | 
    Where-Object { $_.CreationTime -lt (Get-Date).AddHours(-6) }
If ($SpooledJobs) {
    Write-Warning "Old job detected; restarting print spooler service"
    Restart-Service -Name Spooler
}
