
Get-Command -Module Microsoft.PowerShell.Management

(Get-Service | Measure-Object).Count

Restart-Service -Name Spooler
