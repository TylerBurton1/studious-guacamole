get-command *-service
get-command *-service*
get-command *service*
Get-Service | Measure-Object
get-childitem | Measure-Object -Property Length -Maximum -Minimum -Sum -Average
get-childitem .\Documents\ | Measure-Object -Property Length -Maximum -Minimum -Sum -Average
get-service
get-service | get-member
Get-Service | Select-Object -Property Name,Status,StartType,BinaryPathName
Get-Service | Where-Object { $_.Status -eq 'Running' } | Select-Object Name,Status,StartType,BinaryPathName |
    ConvertTo-HTML | Out-File ("{2}\Services-{0:MMddyyyy}.{1}" -f (get-date),"htm",$env:TEMP)
 ("{2}\Services-{0:MMddyyyy}.{1}" -f (get-date),"htm",$env:TEMP)
start-process  ("{2}\Services-{0:MMddyyyy}.{1}" -f (get-date),"htm",$env:TEMP)
Get-Service | Where-Object { $_.Status -eq 'Running' } | ConvertTo-JSON |
    Out-File ("{2}\Services-{0:MMddyyyy}.{1}" -f (get-date),"json",$env:TEMP)
start-process  ("{2}\Services-{0:MMddyyyy}.{1}" -f (get-date),"json",$env:TEMP)
clse
cls
cd 'C:\Users\live\OneDrive\Opsgility\Classes\AZ-040\20220915'
& '.\Exercise -services.ps1' 
& '.\Exercise -services.ps1' -RootFolder C:\Temp
& '.\Exercise -services.ps1' -RootFolder C:\Temp
& '.\Exercise -services.ps1' -RootFolder C:\Temp
& '.\Exercise 5-services.ps1' -LogIdentity TESTING
dir $env:temp\*TESTING*
& '.\Exercise 5-services.ps1'
dir $env:TEMP\*09152022*
$history
get-history
(get-history).commandline
(get-history).commandline | Set-Clipboard
