
param(
    [string]$RootFolder=$env:TEMP,
    [string]$LogIdentity=((get-date).tostring('MMddyyyy'))
)

Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Running' } | Select-Object Name,Status,StartType,BinaryPathName |
ConvertTo-HTML | Out-File ("{2}\Services-{0}.{1}" -f $LogIdentity,"htm",$RootFolder)

Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Running' } | ConvertTo-JSON -Depth 4 |
Out-File ("{2}\Services-{0}.{1}" -f $LogIdentity,"json",$RootFolder)

$LogFiles = Get-CHildItem -Path ("{1}\Services-{0}*" -f $LogIdentity,$RootFolder) -File
If ($LogFiles.Count -ge 2) {
    Write-Host "All is good"
} else  {
    Write-Error "FILE is Misssing"
}
